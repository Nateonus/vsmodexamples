dotnet run --project ./ZZCakeBuild/CakeBuild.csproj -- "$@"
